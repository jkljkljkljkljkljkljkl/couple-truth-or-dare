const defaultQuestionBank = {
  truth: {
    light: [
      "第一次对我有一点点心动，是在哪个瞬间？",
      "如果要用一种甜品形容我，你会选什么？为什么？",
      "我身上哪个小习惯最容易让你觉得可爱？",
      "你觉得我们最适合一起去做的一件小事是什么？",
      "如果今天只能夸我一个点，你会夸什么？",
      "你第一次见我时，对我的第一印象是什么？",
      "你最喜欢我们聊天时的哪种状态？",
      "如果给我们的关系配一首歌，你会想到哪一首？",
      "你觉得我最像哪种天气？为什么？",
      "你最想和我一起打卡的一家店或一个地方是哪里？",
      "我做过哪件小事，让你偷偷开心了很久？",
      "如果要给我起一个专属昵称，你会叫什么？"
    ],
    spark: [
      "你最喜欢我哪一个靠近你的瞬间？",
      "你觉得我什么时候最有吸引力？",
      "如果现在可以抱我 10 秒，你会先说什么？",
      "你最喜欢和我牵手、拥抱还是对视？为什么？",
      "你最想和我尝试的一次约会氛围是什么样的？",
      "如果今天晚上只能安排一个浪漫环节，你会选什么？",
      "你有没有一个关于我的小心思，一直没说出口？",
      "你觉得我说哪句话时最让你心动？",
      "如果我们现在在海边散步，你最想对我说什么？",
      "你最喜欢我哪种撒娇或可爱的小表情？",
      "如果可以向我讨要一个小奖励，你会想要什么？",
      "你希望我以后多给你哪种偏爱的感觉？"
    ],
    deep: [
      "和我在一起后，你觉得自己有什么好的变化？",
      "你最希望我们一起守护的一件事是什么？",
      "你觉得被爱的时候，自己最在意什么感受？",
      "如果我们以后吵架了，你最希望我怎么哄你？",
      "你眼里‘合适的两个人’应该是什么样子？",
      "在这段关系里，你最感谢我的一件事是什么？",
      "你曾经因为什么瞬间，觉得我们真的越来越像一队人？",
      "你最想和我一起实现的一个小目标是什么？",
      "如果要认真对我说一句谢谢，你会说什么？",
      "你希望未来的我们保留现在的哪种相处方式？",
      "你最怕我误会你什么？",
      "如果让你给我们的关系写一句定义，你会怎么写？"
    ]
  },
  dare: {
    light: [
      "用三个词认真夸夸我，不能重复意思。",
      "模仿一个你觉得我很可爱的瞬间。",
      "给我现场取一个今天专属的甜甜昵称。",
      "对着我做一个最真诚的眨眼微笑。",
      "分享一张你手机里最想和我一起重现的照片或风景。",
      "用‘天气预报’语气播报一下你现在对我的心情。",
      "跟我十指紧扣 15 秒，不许笑场。",
      "给我们的下一次约会起一个电影名。",
      "假装你是主持人，隆重介绍一下‘今天超可爱的我’。",
      "用一句押韵的话形容我们现在的气氛。",
      "现场给我比一个你觉得最适合我的手势爱心。",
      "说出一件今天就可以陪我完成的小事。"
    ],
    spark: [
      "靠近我一点，用很轻的声音说一句心动台词。",
      "和我对视 10 秒，谁先躲开谁就算输。",
      "牵着我的手，认真说一句‘今天也想偏爱你’。",
      "选一个你最喜欢的方式，给我一个 5 秒限定的亲密互动。",
      "给我来一段 15 秒的专属哄人服务。",
      "假装这是约会结尾，对我说一句最有氛围感的告别词。",
      "在不肉麻到夸张的前提下，说一句会让我心动的话。",
      "把我夸到不能立刻接上话为止。",
      "如果现在要拍一张氛围感合照，请先摆好动作并邀请我。",
      "用你觉得最撩但不油的方式，重新跟我打一次招呼。",
      "坐到我旁边，肩膀轻轻靠我 15 秒。",
      "给我一个‘你今天表现很好’版本的温柔奖励。"
    ],
    deep: [
      "认真看着我，说一件你想和我一起坚持很久的事。",
      "对我说一句你平时不太会主动表达的感谢。",
      "分享一个你希望我以后更懂你的点。",
      "用 20 秒描述一下你心里理想的我们。",
      "完成一句话：‘和你在一起以后，我更愿意……’",
      "说一个你觉得我们应该慢慢建立的小仪式感。",
      "认真讲一个你想和我一起完成的小愿望。",
      "对我承诺一件这周内可以做到的小事。",
      "说一句如果我低落时你会想对我讲的话。",
      "回忆一个我们之间让你觉得很踏实的瞬间，并讲给我听。",
      "邀请我和你做一个只有我们知道的小约定。",
      "给未来的我们留一句现在就想说的话。"
    ]
  }
};

const storageKey = "couple-truth-or-dare-custom-questions";
const exportFileVersion = 1;
const validModes = ["truth", "dare"];
const validCategories = ["light", "spark", "deep"];

const modeTextMap = {
  truth: "真心话",
  dare: "大冒险"
};

const categoryTextMap = {
  all: "全部题库",
  light: "轻松",
  spark: "升温",
  deep: "走心"
};

const sourceTextMap = {
  mixed: "默认 + 自定义",
  default: "仅默认",
  custom: "仅自定义"
};

const questionTipMap = {
  truth: "小提示：真心话适合慢一点玩，认真回答会更有感觉。",
  dare: "小提示：大冒险可以甜一点、闹一点，但记得尊重彼此边界。"
};

const state = {
  mode: "truth",
  category: "all",
  source: "mixed",
  currentPool: [],
  currentIndex: 0,
  round: 0,
  hasStarted: false,
  previousScreen: "home"
};

const homeScreen = document.getElementById("homeScreen");
const gameScreen = document.getElementById("gameScreen");
const customScreen = document.getElementById("customScreen");
const modeButtons = document.querySelectorAll(".mode-button");
const modeSwitchButtons = document.querySelectorAll("[data-mode-switch]");
const categoryButtons = document.querySelectorAll(".chip[data-category]");
const sourceButtons = document.querySelectorAll(".source-chip");
const modeBadge = document.getElementById("modeBadge");
const categoryBadge = document.getElementById("categoryBadge");
const sourceBadge = document.getElementById("sourceBadge");
const countBadge = document.getElementById("countBadge");
const roundHint = document.getElementById("roundHint");
const questionText = document.getElementById("questionText");
const questionTip = document.getElementById("questionTip");
const drawBtn = document.getElementById("drawBtn");
const nextBtn = document.getElementById("nextBtn");
const restartBtn = document.getElementById("restartBtn");
const backHomeBtn = document.getElementById("backHomeBtn");
const openCustomBtn = document.getElementById("openCustomBtn");
const openCustomFromGameBtn = document.getElementById("openCustomFromGameBtn");
const backFromCustomBtn = document.getElementById("backFromCustomBtn");
const homeCustomCount = document.getElementById("homeCustomCount");
const customQuestionForm = document.getElementById("customQuestionForm");
const customModeSelect = document.getElementById("customModeSelect");
const customCategorySelect = document.getElementById("customCategorySelect");
const customQuestionInput = document.getElementById("customQuestionInput");
const customFormStatus = document.getElementById("customFormStatus");
const customCountText = document.getElementById("customCountText");
const customQuestionList = document.getElementById("customQuestionList");
const exportCustomBtn = document.getElementById("exportCustomBtn");
const importCustomBtn = document.getElementById("importCustomBtn");
const importFileInput = document.getElementById("importFileInput");
const importStatus = document.getElementById("importStatus");

function shuffle(list) {
  const cloned = [...list];
  for (let i = cloned.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [cloned[i], cloned[j]] = [cloned[j], cloned[i]];
  }
  return cloned;
}

function createQuestionId() {
  return `custom-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function normalizeQuestionText(text) {
  return typeof text === "string" ? text.trim().replace(/\s+/g, " ") : "";
}

function createQuestionUniqueKey(mode, category, text) {
  return `${mode}__${category}__${normalizeQuestionText(text)}`;
}

function normalizeCustomQuestion(raw) {
  if (!raw || typeof raw !== "object") {
    return null;
  }

  const mode = validModes.includes(raw.mode) ? raw.mode : null;
  const category = validCategories.includes(raw.category) ? raw.category : null;
  const text = normalizeQuestionText(raw.text);

  if (!mode || !category || !text) {
    return null;
  }

  return {
    id: typeof raw.id === "string" && raw.id ? raw.id : createQuestionId(),
    mode,
    category,
    text
  };
}

function dedupeCustomQuestions(questionList) {
  const seen = new Set();
  const result = [];

  questionList.forEach((item) => {
    const normalized = normalizeCustomQuestion(item);
    if (!normalized) {
      return;
    }

    const uniqueKey = createQuestionUniqueKey(
      normalized.mode,
      normalized.category,
      normalized.text
    );

    if (seen.has(uniqueKey)) {
      return;
    }

    seen.add(uniqueKey);
    result.push(normalized);
  });

  return result;
}

function loadCustomQuestions() {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }

    return dedupeCustomQuestions(parsed);
  } catch (error) {
    console.warn("读取自定义题库失败，已使用空列表。", error);
    return [];
  }
}

function saveCustomQuestions() {
  localStorage.setItem(storageKey, JSON.stringify(state.customQuestions));
}

function setStatusMessage(element, message, type = "info") {
  element.textContent = message;
  element.dataset.state = type;
}

function updateQuestionBankAfterChange() {
  saveCustomQuestions();
  renderCustomQuestions();
  resetRound(true);
}

state.customQuestions = loadCustomQuestions();

function getGroupedQuestions(mode, category, source = state.source) {
  const result = [];

  if (source !== "custom") {
    const defaultGroups = defaultQuestionBank[mode];
    const defaultCategories = category === "all" ? validCategories : [category];

    defaultCategories.forEach((itemCategory) => {
      defaultGroups[itemCategory].forEach((text) => {
        result.push({ text, category: itemCategory, source: "default" });
      });
    });
  }

  if (source !== "default") {
    state.customQuestions.forEach((item) => {
      if (item.mode !== mode) {
        return;
      }

      if (category !== "all" && item.category !== category) {
        return;
      }

      result.push({
        id: item.id,
        text: item.text,
        category: item.category,
        source: "custom"
      });
    });
  }

  return result;
}

function rebuildPool() {
  state.currentPool = shuffle(getGroupedQuestions(state.mode, state.category, state.source));
  state.currentIndex = 0;
  updateStatus();
}

function updateStatus() {
  const total = getGroupedQuestions(state.mode, state.category, state.source).length;
  const left = Math.max(total - state.currentIndex, 0);

  modeBadge.textContent = modeTextMap[state.mode];
  categoryBadge.textContent = categoryTextMap[state.category];
  sourceBadge.textContent = sourceTextMap[state.source];
  countBadge.textContent = `可抽题目：${left}/${total}`;
  roundHint.textContent = state.hasStarted
    ? `第 ${state.round} 题，慢慢玩更有感觉`
    : "准备开始你们的甜蜜回合";

  modeSwitchButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.modeSwitch === state.mode);
  });

  categoryButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.category === state.category);
  });

  sourceButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.source === state.source);
  });

  drawBtn.textContent = state.hasStarted ? "重新抽一题" : "开始抽题";
}

function setQuestion(text, tip) {
  questionText.textContent = text;
  questionTip.textContent = tip;
}

function drawQuestion() {
  const total = getGroupedQuestions(state.mode, state.category, state.source).length;
  if (!total) {
    setQuestion(
      state.source === "custom"
        ? "当前筛选下还没有自定义题目。"
        : "当前分类暂时没有题目。",
      state.source === "custom"
        ? "可以去“自定义题库”里添加新题，或切换为混合模式再试试。"
        : "你可以切换模式、分类或题库范围再试试。"
    );
    return;
  }

  if (state.currentPool.length === 0 || state.currentIndex >= state.currentPool.length) {
    rebuildPool();
    setQuestion(
      "这一轮题目已经抽完啦，已自动为你重新洗牌。",
      "继续点‘下一题’，会从新的随机顺序开始。"
    );
    return;
  }

  const current = state.currentPool[state.currentIndex];
  state.currentIndex += 1;
  state.round += 1;
  state.hasStarted = true;

  const sourceLabel = current.source === "custom" ? "自定义题库" : "默认题库";
  setQuestion(
    current.text,
    `${modeTextMap[state.mode]} · ${categoryTextMap[current.category]} · ${sourceLabel} · 认真玩会更甜。`
  );
  updateStatus();
}

function resetRound(showIntro = true) {
  state.currentIndex = 0;
  state.round = 0;
  state.hasStarted = false;
  rebuildPool();

  if (showIntro) {
    setQuestion("点击下方按钮，开始抽取你们的第一题。", questionTipMap[state.mode]);
  }

  updateStatus();
}

function switchMode(mode) {
  state.mode = mode;
  resetRound(true);
}

function switchCategory(category) {
  state.category = category;
  resetRound(true);
}

function switchSource(source) {
  state.source = source;
  resetRound(true);
}

function hideAllScreens() {
  homeScreen.classList.remove("active");
  gameScreen.classList.remove("active");
  customScreen.classList.remove("active");
}

function showGameScreen(mode = state.mode) {
  state.mode = mode;
  hideAllScreens();
  gameScreen.classList.add("active");
  resetRound(true);
}

function showHomeScreen() {
  hideAllScreens();
  homeScreen.classList.add("active");
}

function showCustomScreen(fromScreen = "home") {
  state.previousScreen = fromScreen;
  hideAllScreens();
  customScreen.classList.add("active");
  renderCustomQuestions();
}

function goBackFromCustom() {
  if (state.previousScreen === "game") {
    hideAllScreens();
    gameScreen.classList.add("active");
    return;
  }

  showHomeScreen();
}

function updateCustomSummary() {
  const total = state.customQuestions.length;
  customCountText.textContent = `共 ${total} 题`;
  homeCustomCount.textContent = total
    ? `你已经添加了 ${total} 道自定义题目，抽题时可以和默认题库一起使用。`
    : "还没有自定义题目，先加几道更有你们自己的味道。";
}

function renderCustomQuestions() {
  updateCustomSummary();

  if (!state.customQuestions.length) {
    customQuestionList.innerHTML = `
      <div class="empty-card">
        <strong>题库还是空的</strong>
        <p>先添加一题吧。你可以选择真心话 / 大冒险，再选轻松、升温或走心分类。</p>
      </div>
    `;
    return;
  }

  const sortedQuestions = [...state.customQuestions].reverse();
  customQuestionList.innerHTML = sortedQuestions
    .map(
      (item) => `
        <article class="custom-item">
          <div class="custom-item-head">
            <div class="custom-tags">
              <span class="custom-tag mode-${item.mode}">${modeTextMap[item.mode]}</span>
              <span class="custom-tag category-tag">${categoryTextMap[item.category]}</span>
            </div>
            <button class="delete-button" data-delete-id="${item.id}">删除</button>
          </div>
          <p class="custom-item-text">${escapeHtml(item.text)}</p>
        </article>
      `
    )
    .join("");
}

function escapeHtml(text) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function addCustomQuestion(mode, category, text) {
  const normalized = normalizeCustomQuestion({
    id: createQuestionId(),
    mode,
    category,
    text
  });

  if (!normalized) {
    return { success: false, reason: "invalid" };
  }

  const duplicateExists = state.customQuestions.some(
    (item) =>
      createQuestionUniqueKey(item.mode, item.category, item.text) ===
      createQuestionUniqueKey(normalized.mode, normalized.category, normalized.text)
  );

  if (duplicateExists) {
    return { success: false, reason: "duplicate" };
  }

  state.customQuestions.push(normalized);
  updateQuestionBankAfterChange();
  return { success: true, reason: "added" };
}

function deleteCustomQuestion(id) {
  const nextList = state.customQuestions.filter((item) => item.id !== id);
  if (nextList.length === state.customQuestions.length) {
    return;
  }

  state.customQuestions = nextList;
  updateQuestionBankAfterChange();
  setStatusMessage(importStatus, "已删除 1 道自定义题目。", "info");
}

function buildExportPayload() {
  return {
    app: "couple-truth-or-dare",
    type: "custom-question-bank",
    version: exportFileVersion,
    exportedAt: new Date().toISOString(),
    total: state.customQuestions.length,
    questions: state.customQuestions.map((item) => ({
      mode: item.mode,
      category: item.category,
      text: item.text
    }))
  };
}

function downloadTextFile(filename, content, mimeType = "application/json;charset=utf-8") {
  const blob = new Blob([content], { type: mimeType });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = objectUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(objectUrl);
}

function exportCustomQuestions() {
  const payload = buildExportPayload();
  const dateText = new Date().toISOString().slice(0, 10);
  const filename = `couple-truth-or-dare-custom-${dateText}.json`;
  downloadTextFile(filename, JSON.stringify(payload, null, 2));
  setStatusMessage(
    importStatus,
    payload.total
      ? `导出成功：已导出 ${payload.total} 道自定义题目。`
      : "导出成功：当前题库为空，已导出一个空题库 JSON 文件。",
    "success"
  );
}

function getImportQuestionsFromPayload(payload) {
  if (!payload || typeof payload !== "object") {
    return null;
  }

  if (Array.isArray(payload)) {
    return payload;
  }

  if (Array.isArray(payload.questions)) {
    return payload.questions;
  }

  return null;
}

function importCustomQuestionsFromText(text) {
  let parsed;

  try {
    parsed = JSON.parse(text);
  } catch (error) {
    return {
      ok: false,
      message: "导入失败：文件不是有效的 JSON。"
    };
  }

  const importQuestions = getImportQuestionsFromPayload(parsed);
  if (!importQuestions) {
    return {
      ok: false,
      message: "导入失败：未找到可用的题目数组，请使用此前导出的 JSON 文件。"
    };
  }

  const normalizedIncoming = [];
  let invalidCount = 0;

  importQuestions.forEach((item) => {
    const normalized = normalizeCustomQuestion(item);
    if (!normalized) {
      invalidCount += 1;
      return;
    }

    normalizedIncoming.push(normalized);
  });

  if (!normalizedIncoming.length) {
    return {
      ok: false,
      message: invalidCount
        ? "导入失败：文件里的题目格式都不符合要求。"
        : "导入失败：文件中没有可导入的题目。"
    };
  }

  const mergedList = [...state.customQuestions];
  const existingKeys = new Set(
    state.customQuestions.map((item) => createQuestionUniqueKey(item.mode, item.category, item.text))
  );

  let addedCount = 0;
  let duplicateCount = 0;

  normalizedIncoming.forEach((item) => {
    const uniqueKey = createQuestionUniqueKey(item.mode, item.category, item.text);
    if (existingKeys.has(uniqueKey)) {
      duplicateCount += 1;
      return;
    }

    existingKeys.add(uniqueKey);
    mergedList.push({
      ...item,
      id: createQuestionId()
    });
    addedCount += 1;
  });

  if (!addedCount) {
    return {
      ok: false,
      message: `导入完成：没有新增题目。${duplicateCount ? `已跳过 ${duplicateCount} 道重复题。` : ""}${invalidCount ? ` 已忽略 ${invalidCount} 道无效题。` : ""}`.trim()
    };
  }

  state.customQuestions = dedupeCustomQuestions(mergedList);
  updateQuestionBankAfterChange();

  return {
    ok: true,
    message: `导入成功：新增 ${addedCount} 道题目。${duplicateCount ? `已跳过 ${duplicateCount} 道重复题。` : ""}${invalidCount ? ` 已忽略 ${invalidCount} 道无效题。` : ""}`.trim()
  };
}

modeButtons.forEach((button) => {
  button.addEventListener("click", () => {
    showGameScreen(button.dataset.mode);
  });
});

modeSwitchButtons.forEach((button) => {
  button.addEventListener("click", () => {
    switchMode(button.dataset.modeSwitch);
  });
});

categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    switchCategory(button.dataset.category);
  });
});

sourceButtons.forEach((button) => {
  button.addEventListener("click", () => {
    switchSource(button.dataset.source);
  });
});

openCustomBtn.addEventListener("click", () => showCustomScreen("home"));
openCustomFromGameBtn.addEventListener("click", () => showCustomScreen("game"));
backFromCustomBtn.addEventListener("click", goBackFromCustom);

drawBtn.addEventListener("click", drawQuestion);
nextBtn.addEventListener("click", drawQuestion);
restartBtn.addEventListener("click", () => resetRound(true));
backHomeBtn.addEventListener("click", showHomeScreen);

customQuestionForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const questionTextValue = customQuestionInput.value.trim();
  if (!questionTextValue) {
    setStatusMessage(customFormStatus, "先输入题目内容再添加哦。", "warning");
    customQuestionInput.focus();
    return;
  }

  const result = addCustomQuestion(
    customModeSelect.value,
    customCategorySelect.value,
    questionTextValue
  );

  if (!result.success) {
    if (result.reason === "duplicate") {
      setStatusMessage(customFormStatus, "这道题已经在自定义题库里了，换一道新的吧。", "warning");
      return;
    }

    setStatusMessage(customFormStatus, "添加失败，请检查题目内容后重试。", "error");
    return;
  }

  customQuestionInput.value = "";
  setStatusMessage(customFormStatus, "添加成功，已经保存到当前浏览器。", "success");
});

customQuestionList.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) {
    return;
  }

  const deleteId = target.dataset.deleteId;
  if (!deleteId) {
    return;
  }

  deleteCustomQuestion(deleteId);
});

exportCustomBtn.addEventListener("click", exportCustomQuestions);

importCustomBtn.addEventListener("click", () => {
  importFileInput.click();
});

importFileInput.addEventListener("change", async (event) => {
  const target = event.target;
  const file = target.files && target.files[0];

  if (!file) {
    return;
  }

  try {
    const text = await file.text();
    const result = importCustomQuestionsFromText(text);
    setStatusMessage(importStatus, result.message, result.ok ? "success" : "warning");
  } catch (error) {
    console.error("读取导入文件失败。", error);
    setStatusMessage(importStatus, "导入失败：读取文件时出了点问题，请重试。", "error");
  } finally {
    target.value = "";
  }
});

updateCustomSummary();
renderCustomQuestions();
resetRound(true);
